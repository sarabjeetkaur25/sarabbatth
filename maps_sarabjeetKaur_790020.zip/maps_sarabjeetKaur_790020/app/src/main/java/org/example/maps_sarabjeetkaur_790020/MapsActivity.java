package org.example.maps_sarabjeetkaur_790020;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    Location userLocation;
    LocationManager locationManager;
    LocationListener locationListener;
    Polygon polygon;

    ArrayList<Character> chars = new ArrayList<Character>();
    ArrayList<Location> locations = new ArrayList<Location>();
    ArrayList<Marker> markers = new ArrayList<Marker>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        chars.add('A');
        chars.add('B');
        chars.add('C');
        chars.add('D');

        userLocation = new Location("");
        userLocation.setLatitude(43.6532);
        userLocation.setLongitude(-79.3832);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                userLocation = location;
                System.out.println(location.getLatitude());
            }
        };
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                if(markers.size() == 4){
                    return;
                }

                Location temp = new Location("");
                temp.setLatitude(latLng.latitude);
                temp.setLongitude(latLng.longitude);
                double distance = temp.distanceTo(userLocation);


                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                markerOptions.title(chars.get(0).toString());
                markerOptions.snippet("Distance: " + Math.round(distance/1000) + " Kms");
                markerOptions.draggable(true);
                markerOptions.icon(bitmapDescriptorFromVector(getApplicationContext(), R.drawable.ic_baseline_accessibility_new_24));
                Marker tempMarker = mMap.addMarker(markerOptions);
                tempMarker.showInfoWindow();

                displayAddress(temp);
                locations.add(temp);
                markers.add(tempMarker);
                chars.remove(0);

                if(markers.size() == 4){
                    makePolygon();
                }
            }
        });

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                Location location = new Location("");
                location.setLatitude(marker.getPosition().latitude);
                location.setLongitude(marker.getPosition().longitude);
                displayAddress(location);
                return false;
            }
        });

        mMap.setOnPolygonClickListener(new GoogleMap.OnPolygonClickListener(){
            @Override
            public void onPolygonClick(Polygon polygon) {
                calculateParameter();
            }
        });

        mMap.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(LatLng latLng) {
                for(Marker marker : markers) {
                    if(Math.abs(marker.getPosition().latitude - latLng.latitude) < 0.5 && Math.abs(marker.getPosition().longitude - latLng.longitude) < 0.5) {
                        char c = marker.getTitle().charAt(0);
                        chars.add(c);

                        locations.remove(markers.indexOf(marker));
                        marker.remove();
                        markers.remove(marker);
                        if(polygon != null){
                            polygon.remove();
                        }
                        break;
                    }
                }

            }
        });

        mMap.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {
            @Override
            public void onMarkerDragStart(Marker marker) {
                if(polygon != null){
                    polygon.remove();
                }
                locations.remove(markers.indexOf(marker));
                markers.remove(marker);
            }

            @Override
            public void onMarkerDrag(Marker marker) {

            }

            @Override
            public void onMarkerDragEnd(Marker marker) {
                Location location = new Location("");
                location.setLatitude(marker.getPosition().latitude);
                location.setLongitude(marker.getPosition().longitude);
                locations.add(location);

                markers.add(marker);

                if(markers.size() == 4){
                    makePolygon();
                }
            }
        });
    }

    private void displayAddress(Location location){
        Geocoder geocoder = new Geocoder(this, Locale.CANADA);
        List<Address> addresses;

        try{
            addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            String markerAddress =
                    addresses.get(0).getAddressLine(0);
            Toast.makeText(MapsActivity.this, markerAddress, Toast.LENGTH_SHORT).show();
        }catch(Exception e){
            Toast.makeText(MapsActivity.this,"Some Error Occurred", Toast.LENGTH_SHORT).show();
        }
    }

    private void calculateParameter(){
        double parameter = 0;
        parameter += locations.get(0).distanceTo(locations.get(1));
        parameter += locations.get(1).distanceTo(locations.get(2));
        parameter += locations.get(2).distanceTo(locations.get(3));
        parameter += locations.get(3).distanceTo(locations.get(0));
        String length = "Total Distance: " + Double.toString(Math.round(parameter/1000)) + " Kms";
        Toast.makeText(MapsActivity.this, length, Toast.LENGTH_SHORT).show();
    }

    private void makePolygon(){
        polygon = mMap.addPolygon(new PolygonOptions()
                .clickable(true)
                .fillColor(Color.argb(35,0,255,0))
                .strokeColor(Color.RED)
                .add(
                        new LatLng(locations.get(0).getLatitude(), locations.get(0).getLongitude()),
                        new LatLng(locations.get(1).getLatitude(), locations.get(1).getLongitude()),
                        new LatLng(locations.get(2).getLatitude(), locations.get(2).getLongitude()),
                        new LatLng(locations.get(3).getLatitude(), locations.get(3).getLongitude())
                )
        );
    }

    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId){
        Drawable vectorDrawable  = ContextCompat.getDrawable(context, vectorResId);
        vectorDrawable.setBounds(0,0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getMinimumHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
}